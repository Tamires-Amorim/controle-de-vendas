# Controle de Vendas

Este é um aplicativo Android simples desenvolvido em Kotlin com Jetpack Compose para controle de produtos e estoque.

## Funcionalidades

- Cadastro de produtos com nome, quantidade e preço
- Listagem de produtos em estoque
- Interface simples e funcional

## Como rodar

1. Abra o projeto no Android Studio
2. Compile e execute no emulador ou dispositivo Android físico